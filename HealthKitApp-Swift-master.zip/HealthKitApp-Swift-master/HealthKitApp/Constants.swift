//
//  Constants.swift
//  HealthKitApp
//
//  Created by Ted Rogers on 7/1/14.
//  Copyright (c) 2014 Ted Rogers Consulting, LLC. All rights reserved.
//

import Foundation

enum Constants {
    static let kHealthKitInitialized = "com.tedmrogers.HealthKitInitialized"
}

