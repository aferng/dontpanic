﻿using UnityEngine;
using System.Collections;

public class Spider : MonoBehaviour
{

    private new Animation animation;
    private Vector3 spiderPos;
    private float spiderFinalPos;
    private Vector3 cameraPos;
    private bool Back;

    public AudioClip chitter;
    public AudioClip attack;
    public AudioClip taunt;
    public AudioClip bombshell;
    public AudioClip gunshot;
    public AudioClip machinegun;
    public AudioClip shouting;

    // Use this for initialization
    void Start()
    {
        animation = GetComponent<Animation>();
        animation["idle"].enabled = true;
        animation["idle"].weight = 1.0f;

        spiderFinalPos = 45f;

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        spiderPos = transform.position;

        if (spiderPos.z >= spiderFinalPos)
        {
            if (Input.GetKeyDown(KeyCode.RightArrow))
            {
                animation["attack1"].enabled = true;
                animation["attack1"].weight = 1.0f;
                AudioSource.PlayClipAtPoint(attack, transform.position);
            }
            if (animation["attack1"].normalizedTime > 0 & animation["attack1"].normalizedTime < 0.5)
            {
                cameraPos = Camera.main.transform.position;
                Camera.main.transform.position = new Vector3(0f, cameraPos.y, cameraPos.z - Time.deltaTime * 5f);
            }
            else if (animation["attack1"].normalizedTime >= 0.5 & animation["attack1"].normalizedTime < 1)
            {
                cameraPos = Camera.main.transform.position;
                Camera.main.transform.position = new Vector3(0f, cameraPos.y, cameraPos.z + Time.deltaTime * 5f);
            }

            if (Input.GetKeyDown(KeyCode.DownArrow))
            {
                animation["attack2"].enabled = true;
                animation["attack2"].weight = 1.0f;
                AudioSource.PlayClipAtPoint(attack, transform.position);
            }
            if (animation["attack2"].normalizedTime > 0 & animation["attack2"].normalizedTime < 0.5)
            {
                cameraPos = Camera.main.transform.position;
                Camera.main.transform.position = new Vector3(0f, cameraPos.y, cameraPos.z - Time.deltaTime * 10f);
            }
            else if (animation["attack2"].normalizedTime >= 0.5 & animation["attack2"].normalizedTime < 1)
            {
                cameraPos = Camera.main.transform.position;
                Camera.main.transform.position = new Vector3(0f, cameraPos.y, cameraPos.z + Time.deltaTime * 10f);
            }

            if (Input.GetKeyDown(KeyCode.Space))
            {
                animation["taunt"].enabled = true;
                animation["taunt"].weight = 1.0f;
                AudioSource.PlayClipAtPoint(taunt, transform.position);
            }
        }
        else if (spiderPos.z < spiderFinalPos)
        {
            if (Input.GetKeyDown(KeyCode.UpArrow))
            {
                animation["walk"].speed = 1;
                animation["walk"].time = 0;
                animation["walk"].enabled = true;
                animation["walk"].weight = 1.0f;
                Back = false;
                AudioSource.PlayClipAtPoint(chitter, transform.position);
            }
            if (Input.GetKeyDown(KeyCode.LeftArrow))
            {
                animation["run"].speed = 1;
                animation["run"].time = 0;
                animation["run"].enabled = true;
                animation["run"].weight = 1.0f;
                Back = false;
                AudioSource.PlayClipAtPoint(chitter, transform.position);
            }

            if (animation["walk"].normalizedTime < 1 & animation["walk"].normalizedTime > 0)
            {
                transform.position = new Vector3(spiderPos.x, spiderPos.y, spiderPos.z + Time.deltaTime * 12f);
                Camera.main.transform.rotation = Quaternion.Euler((spiderFinalPos - spiderPos.z) / spiderFinalPos * 0.1f, 180f, 0f);
                Camera.main.transform.position = new Vector3(0f, spiderPos.z / spiderFinalPos * -2f + 5f, 55f);
                Camera.main.fieldOfView = (-spiderPos.z / spiderFinalPos) * 18f + 60f;
            }
            else if (animation["run"].normalizedTime < 1 & animation["run"].normalizedTime > 0)
            {
                transform.position = new Vector3(spiderPos.x, spiderPos.y, spiderPos.z + Time.deltaTime * 23f);
                Camera.main.transform.rotation = Quaternion.Euler((spiderFinalPos - spiderPos.z) / spiderFinalPos * 0.1f, 180f, 0f);
                Camera.main.transform.position = new Vector3(0f, spiderPos.z / spiderFinalPos * -2f + 5f, 55f);
                Camera.main.fieldOfView = (-spiderPos.z / spiderFinalPos) * 18f + 60f;
            }
        }

        if (Input.GetKeyDown(KeyCode.Keypad8))
        {
            animation["walk"].speed = -1;
            animation["walk"].time = animation["walk"].length;
            animation["walk"].enabled = true;
            animation["walk"].weight = 1.0f;
            Back = true;
            AudioSource.PlayClipAtPoint(chitter, transform.position);
        }
        if (Input.GetKeyDown(KeyCode.Keypad4))
        {
            animation["run"].speed = -1;
            animation["run"].time = animation["run"].length;
            animation["run"].enabled = true;
            animation["run"].weight = 1.0f;
            Back = true;
            AudioSource.PlayClipAtPoint(chitter, transform.position);
        }

        if (Back & animation["walk"].normalizedTime < 1 & animation["walk"].normalizedTime > 0)
        {
            transform.position = new Vector3(spiderPos.x, spiderPos.y, spiderPos.z - Time.deltaTime * 12f);
            Camera.main.transform.rotation = Quaternion.Euler((spiderFinalPos - spiderPos.z) / spiderFinalPos * 0.1f, 180f, 0f);
            Camera.main.transform.position = new Vector3(0f, spiderPos.z / spiderFinalPos * -2f + 5f, 55f);
            Camera.main.fieldOfView = (-spiderPos.z / spiderFinalPos) * 18f + 60f;
        }
        if (Back & animation["run"].normalizedTime < 1 & animation["run"].normalizedTime > 0)
        {
            transform.position = new Vector3(spiderPos.x, spiderPos.y, spiderPos.z - Time.deltaTime * 23f);
            Camera.main.transform.rotation = Quaternion.Euler((spiderFinalPos - spiderPos.z) / spiderFinalPos * 0.1f, 180f, 0f);
            Camera.main.transform.position = new Vector3(0f, spiderPos.z / spiderFinalPos * -2f + 5f, 55f);
            Camera.main.fieldOfView = (-spiderPos.z / spiderFinalPos) * 18f + 60f;
        }

        if (Input.GetKeyDown(KeyCode.Keypad1))
        {
            AudioSource.PlayClipAtPoint(bombshell, Camera.main.transform.position);
        }
        if (Input.GetKeyDown(KeyCode.Keypad2))
        {
            AudioSource.PlayClipAtPoint(gunshot, Camera.main.transform.position);
        }
        if (Input.GetKeyDown(KeyCode.Keypad3))
        {
            AudioSource.PlayClipAtPoint(machinegun, Camera.main.transform.position);
        }
        if (Input.GetKeyDown(KeyCode.Keypad4))
        {
            AudioSource.PlayClipAtPoint(shouting, Camera.main.transform.position);
        }

    }



}
